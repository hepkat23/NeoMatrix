"""Compare saved BOOX information independently of collection bookkeeping."""
import copy
import hashlib
import json


_VOLATILE = ('imported_at_utc', 'sources', 'safety', 'match', 'calibre_integration')
_RECORD_LISTS = (
    ('annotations', 'active'), ('annotations', 'raw_rows'),
    ('bookmarks', 'active'), ('bookmarks', 'raw_rows'),
    ('reader_note', 'document_rows'), ('reader_note', 'shape_rows'),
    ('reader_note', 'resource_rows'), ('handwriting_point_files',),
    ('reading_statistics',),
)


def _json(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(',', ':'))


def state_signature(state):
    if not isinstance(state, dict):
        raise ValueError('BOOX state must be an object')
    value = copy.deepcopy(state)
    for key in _VOLATILE:
        value.pop(key, None)
    for path in _RECORD_LISTS:
        parent = value
        for key in path[:-1]:
            parent = parent.get(key) if isinstance(parent, dict) else None
        if isinstance(parent, dict) and isinstance(parent.get(path[-1]), list):
            parent[path[-1]].sort(key=_json)
    return hashlib.sha256(_json(value).encode('utf-8')).hexdigest()
